class CustomViews {

  constructor ()  {

   console.log('pascal bernard')

  }


}

export default CustomViews