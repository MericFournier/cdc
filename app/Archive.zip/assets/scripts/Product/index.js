import ColorPicker from '../ColorPicker'

class Product {

  constructor (product)  {

    //init color picking system
    new ColorPicker(product)

  }

}

export default Product